//
//  CurrencyListDatasource.swift
//  ExchangeRates
//
//  Created by JaGgu Sam on 24/05/21.
//

import Foundation
import UIKit

class CurrencyListDataSource: NSObject, UITableViewDataSource{
    var currencyList: Currency?
    var inputRate: Double = 1
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currencyList?.quotes.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Constants.currenyCell, for: indexPath) as! CurrencyCell
        let rates = inputRate * Array(currencyList?.quotes ?? [:])[indexPath.row].value
        cell.currencyShortLabel.text = Array(currencyList?.quotes ?? [:])[indexPath.row].key
        cell.currencyAmountLabel.text = String(rates)
        return cell
    }
}
