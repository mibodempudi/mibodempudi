//
//  API&Constants.swift
//  ExchangeRates
//
//  Created by JaGgu Sam on 24/05/21.
//

import Foundation

class API {
    static let api = "http://apilayer.net/api/live?"
    static let access_key = "40625e96b25b99edf680ef52437ba7c3"
}

class Constants{
    static let currenyCell = "CurrencyCell"
}
