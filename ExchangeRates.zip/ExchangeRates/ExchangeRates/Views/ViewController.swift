//
//  ViewController.swift
//  ExchangeRates
//
//  Created by JaGgu Sam on 24/05/21.
//

import UIKit
import Reachability

class ViewController: UIViewController, UITableViewDelegate {
    
    @IBOutlet weak var currencyInputTextField: UITextField!
    @IBOutlet weak var selectCurrencyButton: UIButton!
    @IBOutlet weak var currencyListTableView: UITableView!
    var tableViewDataSource = CurrencyListDataSource()
    var getRatesRepository: GetRatesRepositoryProtocol = GetRatesRepository.shared
    var currencyList: Currency?
    var currentValue = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        currencyInputTextField.delegate = self
        currencyListTableView.delegate = self
        currencyListTableView.dataSource = tableViewDataSource
        register()
        getCurrencyRates(source: "USD") // I am sending default because we have limited access to api
    }
    
    func register() {
        currencyListTableView.register(UINib(nibName: Constants.currenyCell, bundle: nil), forCellReuseIdentifier: Constants.currenyCell)
        self.currencyListTableView.estimatedRowHeight = 100
    }
    
    func reloadTableView() {
        DispatchQueue.main.async { [weak self] in
            guard let weakSelf = self else {return}
            weakSelf.currencyListTableView.reloadData()
        }
    }
    
    @IBAction func onClickCurrencyChangeButton(_ sender: Any) {
        let alert = UIAlertController(title: "Alert", message: "As we have limited access to API, we are showing only USD.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true, completion: nil)
        
        //getCurrencyRates(source: selectCurrencyButton.titleLabel?.text)
    }
    
    func setupView() {
        currencyInputTextField.layer.cornerRadius = 5
        currencyInputTextField.layer.borderWidth = 1
        currencyInputTextField.layer.borderColor = UIColor.lightGray.cgColor
        
        selectCurrencyButton.layer.cornerRadius = 5
        selectCurrencyButton.layer.borderWidth = 1
        selectCurrencyButton.layer.borderColor = UIColor.lightGray.cgColor
    }
}

// MARK:- TextField Delegate
extension ViewController: UITextFieldDelegate{
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        currentValue.append(string)
        if let char = string.cString(using: String.Encoding.utf8) {
            let isBackSpace = strcmp(char, "\\b")
            if (isBackSpace == -92) {
                currentValue.removeLast()
            }
        }
        self.tableViewDataSource.inputRate = Double(currentValue) ?? 1
        self.currencyListTableView.reloadData()
        return true
    }
}

// MARK:- Service Call
extension ViewController{
    func getCurrencyRates(source: String?){
        getRatesRepository.getRates(source: source) {[weak self] (result) in
            guard let weakSelf = self else {return}
            weakSelf.currencyList = result
            DispatchQueue.main.async {
                weakSelf.tableViewDataSource.currencyList = weakSelf.currencyList
                weakSelf.currencyListTableView.reloadData()
            }
            
            //            switch result {
            //                case .success(let response, let statusCode):
            //
            //                    // Switch Data Setup as per responses
            //                    switch statusCode {
            //                        case 200:
            //                            print("something", response)
            //                           // weakSelf.tableViewDataSource.currencyList = response.quotes
            //                            weakSelf.reloadTableView()
            //                        default:
            //                            break
            //                    }
            //                case .failure(let error, _):
            //                    switch error {
            //                    case .reachabilityError:
            //                        print("reachabilityError")
            //                    default:
            //                        break
            //                    }
            //            }
        }
    }
}

