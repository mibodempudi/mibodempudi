//
//  CurrencyCell.swift
//  ExchangeRates
//
//  Created by JaGgu Sam on 24/05/21.
//

import UIKit

class CurrencyCell: UITableViewCell {

    @IBOutlet weak var currencyShortLabel: UILabel!
    @IBOutlet weak var currencyFullNameLabel: UILabel!
    @IBOutlet weak var currencyAmountLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
