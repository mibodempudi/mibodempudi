//
//  CurrencyListModel.swift
//  ExchangeRates
//
//  Created by JaGgu Sam on 24/05/21.
//

import Foundation

struct Currency: Codable {
    let success: Bool
    let terms, privacy: String
    let timestamp: Int
    let source: String
    let quotes: [String: Double]
}
