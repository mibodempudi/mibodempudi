//
//  HTTPTask.swift
//  ExchangeRates
//
//  Created by JaGgu Sam on 24/05/21.
//

import Foundation
import UIKit
import Reachability

protocol HTTPTaskProtocol {
    func Get(api: String, complitionHandler: @escaping (Data?, String?)-> Void)
}

class HTTPTask: NSObject, HTTPTaskProtocol{
    func Get(api: String, complitionHandler: @escaping (Data?, String?)-> Void){
        guard let url = URL(string: api) else {return}

            let task = URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
              if let error = error {
                print("Error with fetching rates: \(error)")
                return
              }
              
              guard let httpResponse = response as? HTTPURLResponse,
                    (200...299).contains(httpResponse.statusCode) else {
                print("Error with the response, unexpected status code:")
                return
              }

                if let data = data{
                    complitionHandler(data,"success")
                }
            })
            task.resume()
          }
}

//protocol HTTPTaskProtocol {
//    func GET<T: Codable>(api: String?, config: URLSessionConfiguration?, completionHandler: @escaping (Result<ResponseJSON<T>, TaskError>) -> Void )
//}
//
//class HTTPTask: NSObject{
//
//    func GET<T: Codable>(api: String?,
//                         config: URLSessionConfiguration? = nil,
//                         completionHandler: @escaping (Result<ResponseJSON<T>, TaskError>) -> Void ) {
//        guard let urlAvailable = api else {
//            completionHandler(.failure(.other, nil))
//            return}
//        let url = URL(string: urlAvailable)!
//        sendRequest(url, method: "GET", completionHandler)
//    }
//
//    func sendRequest<T: Codable>(_ url: URL, method: String, contentType: ContentType = .json, sessionConfig: URLSessionConfiguration? = nil, _ completionHandler: @escaping (Result<ResponseJSON<T>, TaskError>) -> Void) {
//        var urlRequest = URLRequest(url: url)
//        urlRequest.httpMethod = method
//
//        urlRequest.timeoutInterval = 120
//        let session = URLSession.shared
//        let task = session.dataTask(with: urlRequest, completionHandler: { data, response, error -> Void in
//            guard let statusCode = (response as? HTTPURLResponse)?.statusCode else {return}
//            do {
//                let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
//                print(json)
//
//                guard let jsonData = data, !jsonData.isEmpty else {
//                    completionHandler(.failure(.noData, statusCode))
//                    return
//                }
//
//                let decoder = JSONDecoder()
//                decoder.keyDecodingStrategy = .convertFromSnakeCase
//                guard let jsonObject = try? decoder.decode(ResponseJSON<T>.self, from: jsonData) else {
//                    completionHandler(.failure(.jsonError, statusCode))
//                    return
//                }
//                print(jsonObject)
//                completionHandler(.success(jsonObject, statusCode))
//            } catch {
//                print("error")
//            }
//        })
//
//        task.resume()
//    }
//}
//
//enum ContentType: String {
//    case json = "application/json"
//    case text = "text/plain"
//}
//
//enum Result<T, TaskError> {
//    case success(T, Int?)
//    case failure(TaskError, Int?)
//}
