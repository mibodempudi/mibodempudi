//
//  GetRates.swift
//  ExchangeRates
//
//  Created by JaGgu Sam on 24/05/21.
//

import Foundation

protocol GetRatesRepositoryProtocol {
    
    func getRates(source:String?, completionHandler: @escaping (Currency) -> Void)
    
    
//    func getRates(source: String?, completionHandler: @escaping (Result<ResponseJSON<Currency>, TaskError>) -> Void)
}

class GetRatesRepository: GetRatesRepositoryProtocol {
    static let shared = GetRatesRepository()
    private init() {}
    func getRates(source:String?, completionHandler: @escaping (Currency) -> Void){
        let task = HTTPTask()
        guard let source = source else {return }
        task.Get(api: API.api + "source=\(source)&access_key=\(API.access_key)", complitionHandler: {
            data, status in
            if let jsonData = data, !jsonData.isEmpty {
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
               guard let ratesSummary = try? decoder.decode(Currency.self, from: jsonData) else {return}
                completionHandler(ratesSummary)
            }
        })
    }
}
    
//    func getRates(source: String?, completionHandler: @escaping (Result<ResponseJSON<Currency>, TaskError>) -> Void) {
//        let task = HTTPTask()
//        guard let source = source else {return }
////        let jsonBody: [String: String]? = ["source": source,
////                                           "access_key": API.access_key]
////        var jsonBodyData: Data?
////        if let body = jsonBody {
////            let encoder = JSONEncoder()
////            encoder.keyEncodingStrategy = .convertToSnakeCase
////            let data = try? encoder.encode(body)
////            jsonBodyData = data
////        }
//
//        task.GET(api: API.api + "source=\(source)&access_key=\(API.access_key)") { (result: Result<ResponseJSON<Currency>, TaskError>) in
//            print(result)
//            DispatchQueue.main.async {
//                completionHandler(result)
//                print(result)
//            }
//        }
//    }


//struct ResponseJSON<T: Codable>: Codable {
//    let success: Bool?
//    let quotes: T?
//    let source: String?
//}
//
//enum TaskError: Error {
//    case httpError(code: String)
//    case reachabilityError
//    case jsonError
//    case noData
//    case other
//}
